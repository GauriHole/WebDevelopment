import random
while 1:
    print("         Choose       Rock        Paper     Scissors      OR    \n.  For  Quit  Game  Type  Exit    ")  
    user_answer = input(" >   Enter Your Choice : ")
    if user_answer == "Exit":
        break
    user_answer = user_answer.lower()
    if user_answer != "rock" and user_answer != "paper" and user_answer != "scissors":
        print(" Please Enter Valid Input ")
    comp_answer = random.choice(["rock","paper","scissors"])
    print(f" //                          Computer Chosed : {comp_answer}     //")
    if user_answer == comp_answer:
        print(".     -----------------    M A T C H   T I E D   -----------------")
        continue
    elif user_answer == "paper" and comp_answer == "rock":
        print(".     -----------------   Y O U   A R E   W I N N E R  -----------------")
        break
    elif user_answer == "rock" and comp_answer == "scissors":
        print(".     -----------------   Y O U   A R E   W I N N E R  -----------------")
        break
    elif user_answer == "scissors" and comp_answer == "paper":
        print(".     -----------------   Y O U   A R E   W I N N E R  -----------------")
        break
    else:
        print(". -------------------------------    Y O U   L O S T   F R O M   C O M P U T E R   ----------------------------")
        break

    
