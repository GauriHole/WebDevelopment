print("\t\t\t ----------     B A N K I N G      S Y S T E M  ----------")
class Bank:
    def __init__(self, init_amount = 0.00):
        self.balance = init_amount
    
    def log_transaction(self,trans_string):
        with open("Transaction_history.txt","a") as file:
            file.write(f"{trans_string} \t\t\t Available Balance :{self.balance} \n")
    
    def withdrawl(self,amount):
        try:
            amount = float(amount)
        except ValueError :
            amount = 0
        if amount:
            self.balance = self.balance - amount
            self.log_transaction(f"Withdrawl Amount : {amount}")

    def deposite(self,amount):
        try:
            amount = float(amount)
        except ValueError :
            amount = 0
        if amount:
            self.balance = self.balance + amount
            self.log_transaction(f"Deposited Amount : {amount}")

account = Bank(50.50)
while True:
    try:
        action = input(" What action you have to do ? \n \t\t 1. Withdrawl \n \t\t 2. Deposite \n ")
        action = action.lower()
    except KeyboardInterrupt:
        print("\n \t\t -----------------    T H A N K      Y O U    !  ---------------")
        break

    if action in ["withdrawl","deposite"]:
        if action == "withdrawl":
            amount = input("\t Enter Withdrwal Amount :")
            account.withdrawl(amount)
        else:
            amount = input("\t Enter Deposite Amount :")
            account.deposite(amount)
        print("\t\t Successfull , \t Your Current Balance :",account.balance)
    else:
        print("\t Sorry , Action Cann't Proceed . Try again ! ! ! ")
